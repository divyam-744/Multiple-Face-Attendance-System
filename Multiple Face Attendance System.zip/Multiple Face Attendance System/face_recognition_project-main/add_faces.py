import os
import cv2
import face_recognition
import pickle
import shutil
import uuid

# Create directories
os.makedirs("data/faces", exist_ok=True)
os.makedirs("temp_faces", exist_ok=True)

# Load Haar Cascade
cascade_path = os.path.join("data", "haarcascade_frontalface_default.xml")
if not os.path.exists(cascade_path):
    print("❌ Haar cascade not found.")
    exit()

facedetect = cv2.CascadeClassifier(cascade_path)

# Webcam & input
cam = cv2.VideoCapture(0)
user_name = input("Enter your name: ").strip().lower()
temp_id = str(uuid.uuid4())[:8]
temp_path = os.path.join("temp_faces", temp_id)
os.makedirs(temp_path, exist_ok=True)

# Capture 100 face images
count = 0
while True:
    ret, frame = cam.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = facedetect.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        count += 1
        face_img = cv2.resize(gray[y:y+h, x:x+w], (200, 200))
        cv2.imwrite(os.path.join(temp_path, f"{count}.jpg"), face_img)

    cv2.imshow("Press ESC to exit", frame)
    if cv2.waitKey(1) == 27 or count >= 100:
        break

cam.release()
cv2.destroyAllWindows()

if count < 10:
    shutil.rmtree(temp_path)
    exit()

print("Images captured successfully 📸")

# Load known faces
try:
    with open("data/faces_data.pkl", "rb") as f:
        known_encodings = pickle.load(f)
    with open("data/names.pkl", "rb") as f:
        known_names = pickle.load(f)
    if len(known_encodings) != len(known_names):
        known_encodings = []
        known_names = []
except:
    known_encodings = []
    known_names = []

# Check for duplicate
match_counts = {}
for img_file in os.listdir(temp_path):
    img_path = os.path.join(temp_path, img_file)
    gray_img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if gray_img is None:
        continue

    rgb_img = cv2.cvtColor(gray_img, cv2.COLOR_GRAY2RGB)
    encodings = face_recognition.face_encodings(rgb_img)
    if not encodings:
        continue

    encoding = encodings[0]
    matches = face_recognition.compare_faces(known_encodings, encoding, tolerance=0.45)

    for idx, match in enumerate(matches):
        if match:
            name = known_names[idx]
            match_counts[name] = match_counts.get(name, 0) + 1

# Result
if match_counts:
    best_match = max(match_counts, key=match_counts.get)
    match_ratio = match_counts[best_match] / count
    if match_ratio >= 0.5:
        print(f"Already registered as '{best_match}' ❌")
        shutil.rmtree(temp_path)
        exit()

# Save if unique
next_id = len(os.listdir("data/faces"))
final_path = os.path.join("data/faces", f"{user_name}_{next_id}")
shutil.move(temp_path, final_path)
print("Face registered successfully ✅")