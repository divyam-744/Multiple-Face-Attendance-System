import cv2
import pickle
import numpy as np
import os
import csv
import time
from datetime import datetime
from win32com.client import Dispatch
import face_recognition
import sys
from sklearn.neighbors import KNeighborsClassifier

def speak(text):
    speaker = Dispatch("SAPI.SpVoice")
    speaker.Speak(text)

# Setup
video = cv2.VideoCapture(0)

# Load trained face data
with open('data/names.pkl', 'rb') as w:
    LABELS = pickle.load(w)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

FACES = np.array(FACES)
LABELS = LABELS[:len(FACES)]

# Train KNN classifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(FACES, LABELS)

# Optional background
img_path = os.path.join("data", "background2.png")
imgBackground = cv2.imread(img_path)
if imgBackground is None:
    print(f"⚠️ Warning: Background image not found. Proceeding without it.")
    imgBackground = None

COL_NAMES = ['NAME', 'ENTRY_TIME', 'EXIT_TIME']
attendance_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Attendance")
os.makedirs(attendance_folder, exist_ok=True)

crop_w, crop_h = 580, 360
x_offset = 80
y_offset = 200

recognized_faces_today = {}

while True:
    ret, frame = video.read()
    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)

    date = datetime.now().strftime("%d-%m-%Y")
    timestamp = datetime.now().strftime("%H:%M:%S")

    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        distances, indices = knn.kneighbors([face_encoding], n_neighbors=1)

        if distances[0][0] < 0.4:
            name = knn.predict([face_encoding])[0]
            if name not in recognized_faces_today:
                recognized_faces_today[name] = timestamp

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.rectangle(frame, (left, top - 40), (right, top), (0, 255, 0), -1)
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
        else:
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.rectangle(frame, (left, top - 40), (right, top), (0, 0, 255), -1)
            cv2.putText(frame, "Unknown", (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)

    # People count
    cv2.putText(frame, f"People in frame: {len(face_locations)}", (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)

    # Display frame
    if imgBackground is not None:
        try:
            h, w = frame.shape[:2]
            x_center = w // 2
            y_center = h // 2
            x1 = x_center - crop_w // 2
            y1 = y_center - crop_h // 2
            frame_cropped = frame[y1:y1 + crop_h, x1:x1 + crop_w]
            imgBackground[y_offset:y_offset + crop_h, x_offset:x_offset + crop_w] = frame_cropped
            cv2.imshow("Frame", imgBackground)
        except Exception as e:
            print("Display error:", e)
            cv2.imshow("Frame", frame)
    else:
        cv2.imshow("Frame", frame)

    key = cv2.waitKey(1)

    if key == ord('o'):
        filename = os.path.join(attendance_folder, f"Attendance_{date}.csv")
        existing_entries = {}

        if os.path.exists(filename):
            with open(filename, "r", newline='') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    existing_entries[row["NAME"]] = row

        final_attendances = []
        for name, entry_time in recognized_faces_today.items():
            if name in existing_entries and not existing_entries[name].get('EXIT_TIME'):
                print(f"❌ Previous session not exited for {name}")
                speak(f"Previous session not exited for {name}")
            elif name not in existing_entries or existing_entries[name].get('EXIT_TIME'):
                final_attendances.append([name, entry_time, ""])

        if final_attendances:
            with open(filename, "a", newline='') as csvfile:
                writer = csv.writer(csvfile)
                if os.stat(filename).st_size == 0:
                    writer.writerow(COL_NAMES)
                for attendance in final_attendances:
                    writer.writerow(attendance)
                    print(f"✅ Attendance marked for {attendance[0]} at {attendance[1]}")
                    speak(f"Attendance marked for {attendance[0]}")
        else:
            print("⚠️ No new attendance marked.")
            speak("No new attendance marked.")

        break

    if key == ord('q'):
        break

video.release()
cv2.destroyAllWindows()
sys.exit(0)
