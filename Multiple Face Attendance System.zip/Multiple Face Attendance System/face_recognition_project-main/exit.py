import cv2
import pickle
import numpy as np
import os
import csv
import time
from datetime import datetime
from win32com.client import Dispatch
import face_recognition
import sys

def speak(text):
    speaker = Dispatch("SAPI.SpVoice")
    speaker.Speak(text)

# Load trained face data
with open('data/names.pkl', 'rb') as w:
    LABELS = pickle.load(w)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

FACES = np.array(FACES)
LABELS = LABELS[:len(FACES)]

video = cv2.VideoCapture(0)

attendance_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Attendance")
os.makedirs(attendance_folder, exist_ok=True)

ts = time.time()
date = datetime.fromtimestamp(ts).strftime("%d-%m-%Y")
filename = os.path.join(attendance_folder, f"Attendance_{date}.csv")

if not os.path.exists(filename):
    print("❌ No attendance file found for today.")
    speak("No attendance file found for today.")
    sys.exit(1)

print("📷 Please look into the camera for exit scan...")

recognized_names = []
timestamp = datetime.now().strftime("%H:%M:%S")

while True:
    ret, frame = video.read()
    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)

    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        matches = face_recognition.compare_faces(FACES, face_encoding, tolerance=0.45)
        face_distances = face_recognition.face_distance(FACES, face_encoding)

        best_match_index = np.argmin(face_distances)
        if matches[best_match_index]:
            name = LABELS[best_match_index]
            if name not in recognized_names:
                recognized_names.append(name)
                print(f"✅ Face recognized: {name}")

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.rectangle(frame, (left, top - 40), (right, top), (0, 255, 0), -1)
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
        else:
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.putText(frame, "Unknown", (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 1)

    cv2.putText(frame, f"People in frame: {len(face_locations)}", (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)

    cv2.imshow("Exit Scanner", frame)

    key = cv2.waitKey(1)
    if key == ord('o'):  # Press 'o' to confirm exit
        break
    if key == ord('q'):
        video.release()
        cv2.destroyAllWindows()
        sys.exit(0)

video.release()
cv2.destroyAllWindows()

if recognized_names:
    rows = []
    updated = False

    with open(filename, "r", newline='') as file:
        reader = csv.DictReader(file)
        fieldnames = [fn for fn in reader.fieldnames if fn] if reader.fieldnames else ['NAME', 'ENTRY_TIME']
        if 'EXIT_TIME' not in fieldnames:
            fieldnames.append('EXIT_TIME')

        for row in reader:
            # Remove any bad keys like None
            if None in row:
                del row[None]

            name = row.get('NAME', '')
            if name in recognized_names and not row.get('EXIT_TIME'):
                row['EXIT_TIME'] = timestamp
                print(f"✅ Exit marked for {name} at {timestamp}")
                speak(f"Exit marked for {name}")
                updated = True
                recognized_names.remove(name)
            rows.append(row)

    with open(filename, "w", newline='') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    if not updated:
        print("⚠️ No exit updated. Either already exited or not marked entry.")
        speak("Exit not marked. Either already exited or not entered.")
else:
    speak("No recognizable face found. Exit not marked.")
