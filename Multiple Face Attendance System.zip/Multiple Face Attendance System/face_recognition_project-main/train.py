import os
import cv2
import face_recognition
import pickle

# Paths
DATA_DIR = 'data/faces'
ENCODINGS_FILE = 'data/faces_data.pkl'
NAMES_FILE = 'data/names.pkl'
valid_extensions = ('.jpg', '.jpeg', '.png')

# Load existing data
if os.path.exists(ENCODINGS_FILE) and os.path.exists(NAMES_FILE):
    with open(ENCODINGS_FILE, 'rb') as f:
        known_encodings = pickle.load(f)
    with open(NAMES_FILE, 'rb') as f:
        known_names = pickle.load(f)
else:
    known_encodings = []
    known_names = []

# Sync with current folders — remove deleted ones
current_folders = set(folder for folder in os.listdir(DATA_DIR) if os.path.isdir(os.path.join(DATA_DIR, folder)))
filtered_encodings = []
filtered_names = []

for enc, name in zip(known_encodings, known_names):
    if name in current_folders:
        filtered_encodings.append(enc)
        filtered_names.append(name)

known_encodings = filtered_encodings
known_names = filtered_names

# Detect new folders not yet trained
existing_names = set(known_names)
new_faces_trained = []

for folder in current_folders:
    if folder in existing_names:
        continue

    folder_path = os.path.join(DATA_DIR, folder)
    print(f"🧠 Processing: {folder}")
    trained = False

    for filename in os.listdir(folder_path):
        if not filename.lower().endswith(valid_extensions):
            continue

        file_path = os.path.join(folder_path, filename)
        image = cv2.imread(file_path)
        if image is None:
            print(f"⚠️ Skipped invalid image: {file_path}")
            continue

        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        boxes = face_recognition.face_locations(rgb)
        encodings = face_recognition.face_encodings(rgb, boxes)

        for encoding in encodings:
            known_encodings.append(encoding)
            known_names.append(folder)
            trained = True

    if trained:
        new_faces_trained.append(folder)

# Save updated data
os.makedirs(os.path.dirname(ENCODINGS_FILE), exist_ok=True)
with open(ENCODINGS_FILE, "wb") as f:
    pickle.dump(known_encodings, f)
with open(NAMES_FILE, "wb") as f:
    pickle.dump(known_names, f)

# Final status
if new_faces_trained:
    print("✅ New faces trained:", ", ".join(new_faces_trained))
else:
    print("ℹ️ No new faces to train. All up to date.")